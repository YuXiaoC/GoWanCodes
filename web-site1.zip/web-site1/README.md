> dist目录是可以直接更新到服务器上
```
如果需要修改内容,请按下面操作完成
```

> cnpm install

> bower install
```
//如果你没有安装bower 请全局安装bower
npm install bower -g

进入项目目录,再次执行  bower install

```

> gulp serve
```
//执行语句之前,请修改gulpfile.js
host:'192.168.0.132'     //换成您自己的IP


//如果你没有安装gulp,请执行下面语句
npm install --global gulp

然后在执行  gulp serve
```